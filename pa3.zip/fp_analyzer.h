//author: William Petrik - petrikw@bc.edu
//author: Kevin O'Neill - oneillhn@bc.edu

#include <stdio.h>
#include <stdlib.h> 

#ifdef DOUBLE
#define FP_TYPE double
#define INT_TYPE long
#define INPUT_FORMAT "%lf"
#define EXPONENT_SIZE 11
#define BIAS 1024
#else
#define FP_TYPE float
#define INT_TYPE int
#define INPUT_FORMAT "%f"
#define EXPONENT_SIZE 8
#define BIAS 127
#endif

#define BITS_PER_BYTE 8
#define BUFFER_SIZE 1024

#define FP_SIZE (sizeof(FP_TYPE) * BITS_PER_BYTE)
#define SIGN_SIZE 1
#define MANTISSA_SIZE (FP_SIZE - EXPONENT_SIZE - SIGN_SIZE)


typedef struct Components {
    unsigned INT_TYPE mantissa : MANTISSA_SIZE;
    unsigned INT_TYPE exponent : EXPONENT_SIZE;
    unsigned INT_TYPE sign : SIGN_SIZE;
} Components;

typedef union Converter {
    FP_TYPE f;
    unsigned INT_TYPE u;
    Components components; 
} Converter;

void print_bits(INT_TYPE, size_t);

void print_components(Converter);

FP_TYPE power_of_2(int);

float calc_mantissa (int);

void print_normalized(Converter);

void print_denormalized(Converter);

void print_reconstitution(Converter); 


