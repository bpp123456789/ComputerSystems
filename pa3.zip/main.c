//author: William Petrik - petrikw@bc.edu
//author: Kevin O'Neill - oneillhn@bc.edu

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fp_analyzer.h"


int main (int argc, char * argv[]) {
    Converter converter;    
    if (argc > 1 && strcmp(argv[1], "special") == 0) {
        printf("inf\n");
	converter.f = INFINITY;
	printf("All bits: ");
	print_bits(converter.u, FP_SIZE);
	print_components(converter);

	printf("-inf\n");
	converter.f = -INFINITY;
	printf("All bits: ");
	print_bits(converter.u, FP_SIZE);
	print_components(converter);

	printf("NaN\n");
	converter.f = NAN;
	printf("All bits: ");
	print_bits(converter.u, FP_SIZE);
	print_components(converter);

	printf("-NaN\n");
	converter.f = -NAN;
	printf("All bits: ");
	print_bits(converter.u, FP_SIZE);
	print_components(converter);
    
    } else {
        printf("> "); 
        while (scanf(INPUT_FORMAT, &converter.f) == 1) {
	        printf("All bits: ");
	        print_bits(converter.u, FP_SIZE);
	        print_components(converter);
	        puts(" ");
	        print_reconstitution(converter);
	        printf("> ");
	    }
    }
    return EXIT_SUCCESS;    
}
