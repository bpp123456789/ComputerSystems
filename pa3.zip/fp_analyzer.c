//author: William Petrik - petrikw@bc.edu
//author: Kevin O'Neill - oneillhn@bc.edu

#include "fp_analyzer.h"

void print_bits(INT_TYPE input, size_t size) {
    unsigned INT_TYPE mask = 1ul << (size - 1);   //MAYBE INT_TYPE
    while (mask) {
        putchar((mask & input) != 0 ? '1' : '0');
        mask >>= 1;
    }
    
    putchar('\n');
}

void print_components(Converter converter) {
    printf("Sign: ");
    print_bits(converter.components.sign, SIGN_SIZE);
    printf("Exponent: ");
    print_bits(converter.components.exponent, EXPONENT_SIZE);
    printf("Mantissa: ");
    print_bits(converter.components.mantissa, MANTISSA_SIZE);
}

FP_TYPE power_of_2(int exponent) {
    FP_TYPE result = 1.0; 
    if (exponent >= 0) {
        for (int i = 0; i < exponent; i++){
	        result *= 2;
    	}	    
    } else {
	for (int i = 0; i > exponent; i--){
	    result /= 2;
	    }	
    }
    return result; 
}

float calc_mantissa (int mantissa) {
    float mantissa_value = 0.0; 
    for (int i = MANTISSA_SIZE - 1; i >= 0; i--) {
        if ((mantissa >> i) & 1) {
            mantissa_value += 1.0 / (1 << (MANTISSA_SIZE - i));
        }
    }
    return mantissa_value; 
}

void print_normalized(Converter converter){
    float mantissa = calc_mantissa(converter.components.mantissa);
    printf("Original Value:\n");
    printf("(-1)^{%d} x (1 + %f) x 2^{%d-%d} \n", 
	converter.components.sign, 
	mantissa,
	converter.components.exponent,
	BIAS);
    int sign = converter.components.sign ? -1 : 1; 
    float num = 1 + mantissa;
    int exp = converter.components.exponent - BIAS; 
    printf("   = %d x %f x 2^{%d} \n", sign, num, exp);
    num *= sign; 
    FP_TYPE base = power_of_2(exp); 
    printf("   = %f x %f \n", num, base); 
    printf("   = %.45f \n", num * base); 
}

void print_denormalized(Converter converter){
    float mantissa = calc_mantissa(converter.components.mantissa);
    printf("Original Value:\n");
    printf("(-1)^{%d} x %f x 2^{1-%d} \n", 
	converter.components.sign, 
	mantissa,
	BIAS);
    int sign = converter.components.sign ? -1 : 1; 
    int exp = 1 - BIAS; 
    printf("   = %d x %f x 2^{%d} \n", sign, mantissa, exp);
    mantissa *= sign; 
    FP_TYPE base = power_of_2(abs(exp)); 
    printf("   = %f x 1/%f \n", mantissa, base); 
    printf("   = %.45f \n", mantissa*(1/base)); 
}

void print_reconstitution(Converter converter) { 
	if (converter.components.exponent == 0){
	    print_denormalized(converter);
	} else {
	    print_normalized(converter);
	}
}

